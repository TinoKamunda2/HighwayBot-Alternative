import connection from "../db.js";
import {
  userStatesMap,
  initializeUserState,
  setCorrectAnswer,
  setQuestionType,
  setExplanation,
  setQuestionId,
} from "../userStateManager.js";
import { sendMessageFunction } from "../messagesController/sendMessage.js";
import {
  sendThreeMessageButtonFunction,
  sendImageButtonFunction,
} from "../messagesController/sendButtons.js";
import { getImageBase64, getOrUploadMediaId } from "../mediaController/mediaUtils.js";

export async function sendFailedQuestion(businessPhoneNumberId, user, messageId) {
  try {
    initializeUserState(user);
    const userState = userStatesMap.get(user);

    // 1. Fetch failed question IDs from users table
    const [rows] = await connection.execute(
      "SELECT failed_Qtns FROM users WHERE phone = ?",
      [user]
    );

    if (!rows.length || !rows[0].failed_Qtns) {
      await sendMessageFunction(businessPhoneNumberId, user, messageId, "🎉 You have no failed questions to retry. Well done!");
      return;
    }

    // 2. Split into array and filter already asked
    const failedIds = rows[0].failed_Qtns
      .split(',')
      .map(id => parseInt(id.trim()))
      .filter(Boolean);

    const alreadyAsked = Array.from(userState.askedQuestions);
    const remainingIds = failedIds.filter(id => !alreadyAsked.includes(id));

    if (remainingIds.length === 0) {
      await sendMessageFunction(businessPhoneNumberId, user, messageId, "✅ You’ve already retried all your failed questions.\n\nType *Menu* to return.");
      return;
    }

    // 3. Pick a random question ID from remaining
    const randomId = remainingIds[Math.floor(Math.random() * remainingIds.length)];

    const [questions] = await connection.execute(
      "SELECT * FROM questions WHERE id = ?",
      [randomId]
    );

    if (!questions.length) {
      await sendMessageFunction(businessPhoneNumberId, user, messageId, "⚠️ Question not found. Please try again.");
      return;
    }

    const { id, question, answer, image_no, explanation, question_type } = questions[0];

    setCorrectAnswer(user, answer);
    setQuestionType(user, question_type);
    setExplanation(user, explanation);
    setQuestionId(user, id);
    userState.askedQuestions.add(id); // track asked to avoid duplicates

    const displayNumber = userState.askedQuestions.size;
    const total = userState.totalQuestionsNumber;
    const questionText = `*${displayNumber}/${total}*. ${question}`;

    const buttons = [
      { title: "A", id: "A" },
      { title: "B", id: "B" },
      { title: "C", id: "C" },
    ];

    // 4. Send with or without image
    if (image_no) {
      const imageData = await getImageBase64(image_no);
      if (imageData) {
        const buffer = Buffer.from(imageData, 'base64');
        const mediaId = await getOrUploadMediaId(image_no, buffer, businessPhoneNumberId);
        if (mediaId) {
          await sendImageButtonFunction(businessPhoneNumberId, user, mediaId, questionText, buttons);
        } else {
          console.warn("⚠️ Media upload failed for image_no:", image_no);
          await sendMessageFunction(businessPhoneNumberId, user, messageId, questionText);
        }
      }
    } else {
      await sendThreeMessageButtonFunction(
        businessPhoneNumberId,
        user,
        questionText,
        "A", "B", "C",
        "A", "B", "C"
      );
    }
  } catch (error) {
    console.error("❌ Error sending failed question:", error.message);
    await sendMessageFunction(businessPhoneNumberId, user, messageId, "⚠️ Something went wrong. Please try again.");
  }
}
